# Case #291: unknown encrypt

**状态**: ❌ 失败

## 基本信息

- 用例 ID: `run-mqqa0tp9-o3fisr`
- 插件: `unknown`
- 类型: `encrypt`
- 源路径: ``
- 开始: 2026-06-23 14:41:46
- 结束: 2026-06-23 14:42:16
- 耗时: 30.0s

## 错误信息

```
proxy fetch failed: timeout
```

## Step 原始快照（JSON）

```json
{
  "id": "run-mqqa0tp9-o3fisr",
  "stepDefId": "enc_video_ECv4_mp4_encrypt_filename-false_fn_charset-alnum_fn_deconfuse-true_fn_rounds-4_fn_structured-false_stream_preset-balanced",
  "status": "failure",
  "startedAt": "2026-06-23T06:41:46.077Z",
  "completedAt": "2026-06-23T06:42:16.166Z",
  "durationMs": 30089,
  "error": "proxy fetch failed: timeout"
}
```

---

[返回索引](../cases.md)