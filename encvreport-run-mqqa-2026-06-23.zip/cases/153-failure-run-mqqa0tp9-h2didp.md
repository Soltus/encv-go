# Case #153: unknown encrypt

**状态**: ❌ 失败

## 基本信息

- 用例 ID: `run-mqqa0tp9-h2didp`
- 插件: `unknown`
- 类型: `encrypt`
- 源路径: ``
- 开始: 2026-06-23 14:41:46
- 结束: 2026-06-23 14:42:16
- 耗时: 30.0s

## 错误信息

```
proxy fetch failed: timeout
```

## Step 原始快照（JSON）

```json
{
  "id": "run-mqqa0tp9-h2didp",
  "stepDefId": "enc_video_ECv3_mp4_encrypt_filename-false_fn_charset-alnum_symbols_fn_deconfuse-false_fn_rounds-12_fn_structured-false_stream_preset-quality",
  "status": "failure",
  "startedAt": "2026-06-23T06:41:46.077Z",
  "completedAt": "2026-06-23T06:42:16.166Z",
  "durationMs": 30089,
  "error": "proxy fetch failed: timeout"
}
```

---

[返回索引](../cases.md)